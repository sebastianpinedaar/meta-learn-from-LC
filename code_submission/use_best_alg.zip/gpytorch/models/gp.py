#!/usr/bin/env python3

from ..module import Module


class GP(Module):
    pass
